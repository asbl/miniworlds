from typing import Optional, Union, TYPE_CHECKING
import pygame

import miniworlds.appearances.appearance as appear
import miniworlds.appearances.managers.transformations_costume_manager as transformations_costume_manager

if TYPE_CHECKING:
    import miniworlds.worlds.world as world_mod


class Costume(appear.Appearance):
    """A costume contains one or multiple images

    Every actor has a costume which defines the "look" of the actor.
    You can switch the images in a costume to animate the actor.

    You can create costumes in three common ways:

    * ``actor.add_costume("images/player.png")``
    * ``Costume("images/player.png")`` to create a detached costume with an image
    * ``Costume(actor)`` to create and attach a costume immediately
    * ``Costume(actor, "images/player.png")`` to create, load, and attach immediately
    * ``Costume()`` followed by ``actor.add_costume(costume)`` to attach it later

    Examples:

        Create and attach a costume directly:

        .. code-block:: python

            actor = Actor((20, 30))
            costume = Costume(actor)
            costume.add_image("images/walk1.png")
            costume.add_image("images/walk2.png")

        Create a detached costume first and add it later:

        .. code-block:: python

            actor = Actor((20, 30))
            costume = Costume()
            costume.add_image("images/walk1.png")
            actor.add_costume(costume)
    """

    _managed_creation_depth = 0

    def __init__(self, actor=None, source=None):
        if source is None and self._is_image_source(actor):
            source = actor
            actor = None
        super().__init__()
        self.parent = actor  #: the parent of a costume is the associated actor.
        self.actor = self.parent
        self._initial_source = source
        self._info_overlay = False # managed by property
        self._is_rotatable = False # managed by property in appearance
        self._fill_color = None # managed by property in appearance
        self._border_color = None # managed by property in appearance
        self.transformations_manager = (
            transformations_costume_manager.TransformationsCostumeManager(self)
        )

    @staticmethod
    def _is_image_source(value) -> bool:
        return type(value) in [str, pygame.Surface, tuple, list]

    @classmethod
    def create_managed(cls, actor):
        cls._managed_creation_depth += 1
        try:
            return cls(actor)
        finally:
            cls._managed_creation_depth -= 1

    @classmethod
    def _is_managed_creation(cls) -> bool:
        return getattr(cls, "_managed_creation_depth", 0) > 0

    def bind_to_actor(self, actor) -> None:
        self.parent = actor
        self.actor = actor

    def get_manager(self):
        """Return the owning costume manager of the actor."""
        return self.actor.costume_manager

    @property
    def world(self) -> "world_mod.World":
        """Owning world of this costume."""
        return self.parent.world

    def after_init(self):
        """Apply actor and world defaults after construction."""
        self._set_actor_default_values()
        if self.actor is not None:
            self._set_world_default_values()
        super().after_init()
        if self._initial_source is not None:
            if isinstance(self._initial_source, list):
                self.add_images(self._initial_source)
            else:
                self.add_image(self._initial_source)
        if self.actor is not None and not type(self)._is_managed_creation():
            self.actor.add_costume(self)

    def _set_default_color_values(self):
        self._set_actor_default_values()
        self._set_world_default_values()

    def _set_actor_default_values(self):
        self._info_overlay = False
        self._is_rotatable = True
        self.fill_color = (255, 0, 255, 255)
        self.border_color = (100, 100, 255)

    def _set_world_default_values(self):
        if self.actor.world.draw.default_fill_color:
            self.fill_color = self.world.draw.default_fill_color
        if self.actor.world.draw.default_is_filled:
            self._is_filled = self.world.draw.default_is_filled
        if self.actor.world.draw.default_stroke_color:
            self.border_color = self.world.draw.default_stroke_color
        if self.actor.world.draw.default_border_color:
            self.border_color = self.world.draw.default_border_color
        if self.actor.world.draw.default_border:
            self.border = self.actor.world.draw.default_border

    @property
    def info_overlay(self):
        """Shows info overlay (Rectangle around the actor and Direction marker)"""
        return self._info_overlay

    @info_overlay.setter
    def info_overlay(self, value):
        self._info_overlay = value
        self.set_dirty("all", Costume.RELOAD_ACTUAL_IMAGE)

    def set_image(self, source: Union[int, "appear.Appearance", tuple]) -> bool:
        """
        :param source: index, Appearance or color.
        :return: True if image exists
        """
        return super().set_image(source)

    def _inner_shape(self) -> tuple:
        """Returns inner shape of costume

        Returns:
            pygame.Rect: Inner shape (Rectangle with size of actor)
        """
        size = self.parent.position_manager.get_size()
        return pygame.draw.rect, [pygame.Rect(0, 0, size[0], size[1]), 0]

    def _outer_shape(self) -> tuple:
        """Returns outer shape of costume

        Returns:
            pygame.Rect: Outer shape (Rectangle with size of actors without filling.)
        """
        size = self.parent.position_manager.get_size()
        return pygame.draw.rect, [pygame.Rect(0, 0, size[0], size[1]), self.border]

    def rotated(self):
        """Mark rotation-dependent rendering as dirty after actor rotation."""
        if self.actor._is_actor_repainted():
            self.set_dirty("rotate", self.RELOAD_ACTUAL_IMAGE)

    def origin_changed(self):
        """Mark rendering as dirty after an origin change."""
        if self.actor._is_actor_repainted():
            self.set_dirty("origin_changed", self.RELOAD_ACTUAL_IMAGE)

    def resized(self):
        """Mark scaling-dependent rendering as dirty."""
        self.set_dirty("scale", self.RELOAD_ACTUAL_IMAGE)

    def visibility_changed(self):
        """Mark full rendering as dirty after visibility updates."""
        if self.actor._is_actor_repainted():
            self.set_dirty("all", self.RELOAD_ACTUAL_IMAGE)

    def set_dirty(self, value="all", status=1):
        """Set dirty flags and keep actor rect/mask caches in sync."""
        super().set_dirty(value, status)
        if hasattr(self, "_cached_rect"):
            self._cached_rect = (-1, self._cached_rect[1])
        if hasattr(self, "actor") and self.actor and hasattr(self.actor, "position_manager"):
            self.actor.position_manager._invalidate_rect_cache()
        if (
            hasattr(self, "actor")
            and self.actor
            and self.actor.collision_type == "mask"
        ):
            self.actor.mask = pygame.mask.from_surface(self.actor.image, threshold=100)


    def get_rect(self):
        """Return a frame-cached local rect for the rendered costume image."""
        frame = self.actor.world.frame if self.actor else 0
        if frame == self._cached_rect[0]:
            return self._cached_rect[1]
        rect = self.image.get_rect()
        self._cached_rect = (frame, rect)
        return rect
